
<?php
// Database connection
$servername = "localhost";
$dbname = "u632480160_solarhard";
$username = "u632480160_solarhard";
$password = "root@Ershith#89";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch latest data from the database
$sql = "SELECT * FROM street_light_data ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $weatherCondition = $row['weather_condition'];
    $temperature = $row['temperature'];
    $maintenanceDate = $row['maintenance_date'];
    $maintenanceDetails = $row['maintenance_details'];
    $time = $row['time'];
    $serviceManName = $row['service_man_name'];
    $serviceManLocation = $row['service_man_location'];
    $energyConsumption = $row['energy_consumption'];
} else {
    // Default values if no data found
    $weatherCondition = "N/A";
    $temperature = "N/A";
    $maintenanceDate = "N/A";
    $maintenanceDetails = "N/A";
    $time = "N/A";
    $serviceManName = "N/A";
    $serviceManLocation = "N/A";
    $energyConsumption = "N/A";
}

// Close connection
$conn->close();

// Output data in JSON format
$data = array(
    'weatherCondition' => $weatherCondition,
    'temperature' => $temperature,
    'maintenanceDate' => $maintenanceDate,
    'maintenanceDetails' => $maintenanceDetails,
    'time' => $time,
    'serviceManName' => $serviceManName,
    'serviceManLocation' => $serviceManLocation,
    'energyConsumption' => $energyConsumption
);

echo json_encode($data);
?>
