<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Street Light Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles */
        body {
            font-family: Arial, sans-serif;
        }

        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            padding: 8px 15px;
            color: #fff;
        }

        .sidebar ul li:hover {
            background-color: #555;
        }

        .topbar {
            background-color: #222;
            color: #fff;
            padding: 15px;
            text-align: right;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <!-- Top Bar -->
    <div class="topbar">
        <div class="container">
            <span>Welcome, Admin</span>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
        <ul>
            <a href="https://solarhard.yeezycles.com/gowtham/"><li>Dashboard</li></a>
            <a href="https://solarhard.yeezycles.com/gowtham/"><li>Street Lights</li></a>
            <a href="https://solarhard.yeezycles.com/gowtham/"><li>Weather</li></a>
           <a href="https://solarhard.yeezycles.com/gowtham/"> <li>Maintenance</li></a>
            <a href="https://solarhard.yeezycles.com/gowtham/"><li>Local Service</li></a>
           <a href="https://solarhard.yeezycles.com/gowtham/"> <li>Energy Consumption</li></a>
        </ul>
    </div>

    <!-- Content -->
    <div class="content">
        <div class="container">
            <!-- All fields in one form -->
            <form action="insert.php" method="post">
                <!-- Weather Input -->
                <h4>Weather Input</h4>
                <div class="form-group">
                    <label for="weatherCondition">Weather Condition:</label>
                    <input type="text" class="form-control" id="weatherCondition" name="weatherCondition">
                </div>
                <div class="form-group">
                    <label for="temperature">Temperature:</label>
                    <input type="number" class="form-control" id="temperature" name="temperature">
                </div>

                <!-- Maintenance Data Input -->
                <h4>Maintenance Data Input</h4>
                <div class="form-group">
                    <label for="maintenanceDate">Maintenance Date:</label>
                    <input type="date" class="form-control" id="maintenanceDate" name="maintenanceDate">
                </div>
                <div class="form-group">
                    <label for="maintenanceDetails">Maintenance Details:</label>
                    <textarea class="form-control" id="maintenanceDetails" name="maintenanceDetails" rows="3"></textarea>
                </div>

                <!-- Time Input -->
                <h4>Time Input</h4>
                <div class="form-group">
                    <label for="time">Time:</label>
                    <input type="time" class="form-control" id="time" name="time">
                </div>

                <!-- Local Service Man Contact Input -->
                <h4>Local Service Man Contact Input</h4>
                <div class="form-group">
                    <label for="serviceManName">Service Man Name & Contact:</label>
                    <input type="text" class="form-control" id="serviceManName" name="serviceManName">
                </div>
                <div class="form-group">
                    <label for="serviceManLocation">Service Man Location:</label>
                    <input type="text" class="form-control" id="serviceManLocation" name="serviceManLocation">
                </div>

                <!-- Energy Consumption Input -->
                <h4>Energy Consumption Input</h4>
                <div class="form-group">
                    <label for="energyConsumption">Energy Consumption:</label>
                    <input type="number" class="form-control" id="energyConsumption" name="energyConsumption">
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
