<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Street Light Management System Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            background-image: url('https://i.pinimg.com/originals/96/8b/de/968bdee0c0eb38c81b9ac702333f2e8f.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #333;
            font-family: Arial, sans-serif;
            opacity: 0.9; /* Adjust opacity to your preference */
        }

        .navbar {
            background-color: #007bff !important;
        }

        .navbar-brand {
            color: #fff !important;
        }

        .footer {
            background-color: #007bff;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            width: 100%;
        }

        #map {
            height: 400px;
        }

        .card {
            background-color: rgba(255, 255, 255, 0.8); /* Adjust opacity to your preference */
        }

        .card-header {
            background-color: rgba(0, 123, 255, 0.5); /* Adjust opacity to your preference */
        }

        .card-body {
            background-color: rgba(0, 123, 255, 0.2); /* Adjust opacity to your preference */
        }

        .card-body p {
            margin-bottom: 5px;
        }
    </style>
</head>

<body>
    <!-- Top bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-lightbulb"></i> Street Light Management System</a>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center mt-4 mb-4">Street Light Management System Dashboard</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        Weather Condition
                    </div>
                    <div class="card-body">
                        <p><i class="fas fa-cloud-sun"></i> Weather Condition: <span id="weatherCondition">Loading...</span></p>
                        <p><i class="fas fa-thermometer-half"></i> Temperature: <span id="temperature">Loading...</span>°C</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        Maintenance Information
                    </div>
                    <div class="card-body">
                        <p><i class="fas fa-calendar-day"></i> Maintenance Date: <span id="maintenanceDate">Loading...</span></p>
                        <p><i class="fas fa-tools"></i> Maintenance Details: <span id="maintenanceDetails">Loading...</span></p>
                        <p><i class="far fa-clock"></i> Maintenance Time: <span id="time">Loading...</span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-white">
                        Service Personnel Information
                    </div>
                    <div class="card-body">
                        <p><i class="fas fa-user"></i> Service Man Name: <span id="serviceManName">Loading...</span></p>
                        <p><i class="fas fa-map-marker-alt"></i> Service Man Location: <span id="serviceManLocation">Loading...</span></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        Energy Consumption
                    </div>
                    <div class="card-body">
                        <p><i class="fas fa-bolt"></i> Energy Consumption: <span id="energyConsumption">Loading...</span> kWh</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-12">
            <div id="map"></div>
        </div>
    </div>
    <!-- Footer -->
    <div class="footer">
        <div class="container">
            <p>&copy; 2024 Street Light Management System <b>Designed and Developed by Gowtham & Team</b></p>
        </div>
    </div>

    <!-- Bootstrap JS and jQuery (Optional for Bootstrap features) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Leaflet JavaScript -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>

    <!-- Fetch real-time data from server and update dashboard -->
    <script>
        // Function to fetch real-time data from server
        function fetchData() {
            $.ajax({
                url: 'fetch_data.php',
                dataType: 'json',
                success: function(data) {
                    // Update weather condition
                    $('#weatherCondition').text(data.weatherCondition);
                    $('#temperature').text(data.temperature);

                    // Update maintenance information
                    $('#maintenanceDate').text(data.maintenanceDate);
                    $('#maintenanceDetails').text(data.maintenanceDetails);
                    $('#time').text(data.time);

                    // Update service personnel information
                    $('#serviceManName').text(data.serviceManName);
                    $('#serviceManLocation').text(data.serviceManLocation);

                    // Update energy consumption
                    $('#energyConsumption').text(data.energyConsumption);
                }
            });
        }

        // Update data every 5 seconds
        setInterval(fetchData, 5000); // 5000 milliseconds = 5 seconds

        // Initialize Leaflet map
        var map = L.map('map').setView([12.1277, 78.1579], 10); // Dharmapuri district, Tamil Nadu, India
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Function to update pointers dynamically within Dharmapuri district
        function updatePointers() {
            var points = [{
                    name: "Park light 4 roads",
                    lat: 12.1317,
                    lng: 78.1595
                },
                {
                    name: "street light",
                    lat: 12.1273,
                    lng: 78.1629
                },
                {
                    name: "service road light",
                    lat: 12.1228,
                    lng: 78.1559
                },
                {
                    name: "dharmapuri main road",
                    lat: 12.1289,
                    lng: 78.1516
                }
            ];

            // Update marker positions randomly within Dharmapuri district boundary
            points.forEach(function(point) {
                point.lat += (Math.random() - 0.5) * 0.01; // Adjust latitude randomly within +/- 0.01 degrees
                point.lng += (Math.random() - 0.5) * 0.01; // Adjust longitude randomly within +/- 0.01 degrees
            });

            // Remove existing markers
            map.eachLayer(function(layer) {
                if (layer instanceof L.Marker) {
                    map.removeLayer(layer);
                }
            });

            // Add markers for each point
            points.forEach(function(point) {
                var marker = L.marker([point.lat, point.lng]).addTo(map);
                marker.bindPopup("<b>" + point.name + "</b>").openPopup();
            });
        }

        // Update pointers every 10 seconds
        setInterval(updatePointers, 10000); // 10000 milliseconds = 10 seconds
    </script>
</body>

</html>
