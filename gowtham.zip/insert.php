<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $weatherCondition = $_POST['weatherCondition'];
    $temperature = $_POST['temperature'];
    $maintenanceDate = $_POST['maintenanceDate'];
    $maintenanceDetails = $_POST['maintenanceDetails'];
    $time = $_POST['time'];
    $serviceManName = $_POST['serviceManName'];
    $serviceManLocation = $_POST['serviceManLocation'];
    $energyConsumption = $_POST['energyConsumption'];

    // Insert the data into the database (you should modify this part according to your database setup)
    // Example using PDO (you need to replace 'your_database', 'your_username', 'your_password' and 'your_table' with actual values)
    $dsn = 'mysql:host=localhost;dbname=u632480160_solarhard';
    $username = 'u632480160_solarhard';
    $password = 'root@Ershith#89';

    try {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare SQL statement
        $sql = "INSERT INTO street_light_data (weather_condition, temperature, maintenance_date, maintenance_details, time, service_man_name, service_man_location, energy_consumption) 
                VALUES (:weatherCondition, :temperature, :maintenanceDate, :maintenanceDetails, :time, :serviceManName, :serviceManLocation, :energyConsumption)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':weatherCondition', $weatherCondition);
        $stmt->bindParam(':temperature', $temperature);
        $stmt->bindParam(':maintenanceDate', $maintenanceDate);
        $stmt->bindParam(':maintenanceDetails', $maintenanceDetails);
        $stmt->bindParam(':time', $time);
        $stmt->bindParam(':serviceManName', $serviceManName);
        $stmt->bindParam(':serviceManLocation', $serviceManLocation);
        $stmt->bindParam(':energyConsumption', $energyConsumption);

        // Execute the statement
        $stmt->execute();

        // Close connection
        $pdo = null;

        // Redirect to the admin panel or any other page after successful insertion
        header("Location: admin_panel.php");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    // If the form is not submitted, redirect to the form page
    header("Location: admin_panel.php");
    exit();
}
?>
